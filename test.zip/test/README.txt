Extract files download info from MySQL dump.

All paths are given from the project root.

Usage:

	Launch docker:
		cd docker
		docker-compose up

	Then after text "X Plugin ready for connections" in separate terminal launch `./extract.sh`.

	Cleaning up:
		cd docker
		docker-compose rm SibSoft-mysql

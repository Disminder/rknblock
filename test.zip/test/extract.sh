#!/bin/bash
set -e

QUERY="docker exec -it SibSoft-mysql mysql --login-path=local -Dsibsoft -e"

$QUERY "
	SELECT
		DATE(\`IP2Files\`.\`created\`) as date,
		COUNT(\`IP2Files\`.\`file_id\`) as downloads,
		COUNT(\`IP2Files\`.\`file_id\`) * \`Files\`.\`file_size\` as traffic,
		\`Users\`.\`usr_login\` as owner,
		\`Files\`.\`file_name\` as filename
	FROM \`IP2Files\`
	LEFT JOIN \`Files\` ON \`IP2Files\`.\`file_id\` = \`Files\`.\`file_id\`
	LEFT JOIN \`Users\` ON \`IP2Files\`.\`owner_id\` = \`Users\`.\`usr_id\`
	GROUP BY
		DATE(\`IP2Files\`.\`created\`),
		\`IP2Files\`.\`file_id\`
	ORDER BY
		DATE(\`IP2Files\`.\`created\`) DESC,
		\`downloads\` DESC;
" | tr -d '\r'
